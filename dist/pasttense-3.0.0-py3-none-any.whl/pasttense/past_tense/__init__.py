from pasttense.past_tense import past_tense

