from pasttense.past_tense import past_tense

def demo():
	return past_tense.past_tense()
