#name = "past_tense.py"

from pasttense.past_tense import past_tense
